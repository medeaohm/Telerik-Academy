# TeamPompeii
The Team Pompeii assignment for the SoftUni ASP.NET MVC course teamwork project

## E / R Diagram
### (based on https://developer.foursquare.com/docs/)
https://raw.githubusercontent.com/iordan93/TeamPompeii/master/EntityDiagram.png
