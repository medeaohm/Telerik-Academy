﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PompeiiSquare.Models
{
    public class Gender
    {
        public int Id { get; set; }

        public string GenderName { get; set; }
    }
}
