﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PompeiiSquare.Server.Areas.VenueAdministrator.Models
{
    public class VenueGroupBindingModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
