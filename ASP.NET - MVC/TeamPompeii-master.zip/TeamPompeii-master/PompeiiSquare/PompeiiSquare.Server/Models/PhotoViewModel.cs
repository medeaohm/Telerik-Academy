﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PompeiiSquare.Server.Models
{
    public class PhotoViewModel
    {
        public string Url { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}